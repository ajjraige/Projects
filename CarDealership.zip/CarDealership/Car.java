class Car {
    String make, model, type, transmission;
    int year, seats, wheels;
    double maxSpeed;

    public Car(String make, String model, String transmission, int year, int seats, int maxSpeed, int wheels, String type) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.transmission = transmission;
        this.seats = seats;
        this.maxSpeed = maxSpeed;
        this.wheels = wheels;
        this.type = type;
    }

    @Override
    public String toString() {
        return "Car{" +
                "make='" + make + '\'' +
                ", model='" + model + '\'' +
                ", type='" + type + '\'' +
                ", transmission='" + transmission + '\'' +
                ", year=" + year +
                ", seats=" + seats +
                ", wheels=" + wheels +
                ", maxSpeed=" + maxSpeed +
                '}';
    }

    //setter classes
    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public void setWheels(int wheels) {
        this.wheels = wheels;
    }

    public void setType(String type) {
        this.type = type;
    }

    //my getter classes
    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getTransmission() {
        return transmission;
    }

    public int getYear() {
        return year;
    }

    public int getSeats() {
        return seats;
    }

    public double getMaxSpeed() {
        return maxSpeed;
    }

    public int getWheels() {
        return wheels;
    }

    public String getType() {
        return type;
    }
}