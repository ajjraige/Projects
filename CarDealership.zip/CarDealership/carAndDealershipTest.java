import java.util.ArrayList;

public class carAndDealershipTest {

    public static void main(String[] args) {

        Car carTest = new Car("honda","XR", "CVT", 1969, 5,420,4,"Car");
        Car carTest2 = new Car("hondo","RE", "CT", 1969, 5,420,4,"Car");
        Dealership dt = new Dealership("AJ's Funky Car Maker","Funky Town","Samet", "AJ Jraige");
        Car carTest3 = new Car("jaguar","RE", "CT", 1969, 5,420,4,"Car");
        ArrayList<Car> c= new ArrayList<>();
        c.add(carTest);
        c.add(carTest2);
        c.add(carTest3);
        dt.addCar(carTest2);
        dt.addCar(new Car("jaguar","RE", "CT", 1969, 5,420,4,"Car"));
        dt.printCar();




    }


    }