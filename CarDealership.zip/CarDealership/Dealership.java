import java.io.CharArrayReader;
import java.util.ArrayList;

class Dealership {

    String name, location,managers,employees;
    int numbersOfCars,numbersOfManagers,numbersOfDealership,numbersOfEmployees;




    public Dealership(String name, String location , String employees, String managers){


        this.name = name;
        this.location = location;
        this.employees = employees;
        this.managers = managers;
    }

    public void printCar(){
        for(int n = 0 ; n< cars.size();n++)
        System.out.println(cars.get(n));
    }

    public ArrayList<Car> getCars() {
        return cars;
    }

    ArrayList<Car> cars = new ArrayList<Car>();

    public void addCar(Car cartest){
        cars.add(cartest);

    }

    public void setName(String name) {
        this.name = name;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public void setManagers(String managers) {
        this.managers = managers;
    }
    public void setMake(String employees) {
        this.employees = employees;
    }
    public void setNumbersOfEmployees(int numbersOfEmployees) {
        this.numbersOfEmployees = numbersOfEmployees;
    }
    public void setNumbersOfManagers(int numbersOfManagers) {
        this.numbersOfManagers = numbersOfManagers;
    }
    public void setNumbersOfDealership(int numbersOfDealership) {
        this.numbersOfDealership = numbersOfDealership;
    }
    public void setNumbersOfCars(int numbersOfCars) {
        this.numbersOfCars = numbersOfCars;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getManagers() {
        return managers;
    }

    public String getEmployees() {
        return employees;
    }

    public int getNumbersOfCars() {
        return numbersOfCars;
    }

    public int getNumbersOfManagers() {
        return numbersOfManagers;
    }

    public int getNumbersOfDealership() {
        return numbersOfDealership;
    }

    public int getNumbersOfEmployees() {
        return numbersOfEmployees;
    }
}
