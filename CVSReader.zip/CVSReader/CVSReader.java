package Q2;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class CVSReader {

    ArrayList<String[]> field = new ArrayList<String[]>();
    int row, columns = 0;
    StringBuffer buffer;

    String filename;

    CVSReader(String filename) throws IOException {
        this.filename = filename;


        Scanner scan = new Scanner(new File(filename));
        row = 0;
        while (scan.hasNext()) {
            String line = scan.nextLine();
            String[] tok= line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
            for (int i = 0; i< tok.length;i++){
                tok[i]=tok[i].trim();
                tok[i]=tok[i].replaceAll("\"\"","\"");
                if(tok[i].charAt(0)=='"' && tok[i].charAt(tok[i].length()-1)=='"'){
                   tok[i] =tok[i].substring(1,tok[i].length()-1);
                }
            }
            field.add(tok);
            row++;
        }

    }




    public int numberOfRows() {
        return row;

    }


    // Returns the number of lines in the CSV file
    public int numberOfFields(int row) {

        return field.get(row).length;


    }

    public String field(int row, int column) throws FileNotFoundException {
        return field.get(row)[column];
    }
//            String columns;
//            Scanner scan = new Scanner(new File("att2007.csv"));
//            while (scan.hasNextLine()) {
//
//                columns += scan.nextLine().split(",").length;
//
//                scan.nextLine();
//
//            }
//
//            return columns;
//
//
//    } // Returns the field in a particular row and column
}
